import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class test {
    public static void main(String[] args) {

        final String queueUrl = sqs.createQueue("queue");
        Frame f = new Frame("aws收发装置");

        f.setBounds(400, 200, 400, 300);
        //选择布局方式
        f.setLayout(new FlowLayout());

        //创建文本框
        final TextField tf = new TextField(20);

        //创建按钮
        final Button send = new Button("send");
        final Button receive=new Button("receive");

        //创建文本域
        final TextArea text = new TextArea(10, 40);

        f.add(tf);
        f.add(send);
        f.add(text);
        f.add(receive);

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        //给按钮添加实践
        send.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                // 创建队列
                //获取文本框中的文本
                String tf_str = tf.getText().trim();
                System.out.print(tf_str);
                tf.setText("");
                // 发送信息
                sqs.sendMessage(queueUrl,tf_str);
                //将文本交给文本框
                //ta.setText(tf_str);
                //追加文本
               // send.append(tf_str+"\r\n");

                //将光标移动到tf文本框
                tf.requestFocus();
            }
        });


      receive.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                // 接收Message
               String tf_str = sqs.receiveMessages(queueUrl);
              text.setText(tf_str);

            }
        });

        //设置窗体显示
        f.setVisible(true);

        // 删除队列
     //sqs.deleteQueue(queueUrl);

    }
}
