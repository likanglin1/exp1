import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.*;
import java.util.*;

public class sqs {
    private static AmazonSQS sqs;
    static {
        // 创建一个sqs对象，注意要指定Regions和你消息队列的地区一致
        sqs = AmazonSQSClientBuilder.standard().withRegion(Regions.US_EAST_1).build();
    }
    private sqs() {
    }

    /**
     * 根据Queue Name查询Url
     */
    public static String getQueueUrl(String queueName) {
        return sqs.getQueueUrl(queueName).getQueueUrl();
    }

    static String createQueue(String queueName) {
        System.out.println("创建消息队列：" + queueName);
        CreateQueueRequest createQueueRequest = new CreateQueueRequest(queueName);
        return sqs.createQueue(createQueueRequest).getQueueUrl();
    }

    static void sendMessage(String queueUrl, String message) {
        System.out.println("发送消息： " + queueUrl);
        // 声明一个发送消息的请求
        SendMessageRequest request = new SendMessageRequest();
        // 指定要将消息发送到哪个队列
        request.withQueueUrl(queueUrl);
        // 设置消息内容
        request.withMessageBody(message);
        // 发送消息
        sqs.sendMessage(request);
    }


    static String receiveMessages(String queueUrl) {
        System.out.println("接收消息 " + queueUrl);
        // 声明一个接收消息的请求
        ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(queueUrl);
        // 设置一些参数
        receiveMessageRequest.setMaxNumberOfMessages(5);
        receiveMessageRequest.withWaitTimeSeconds(10);
        // 声明一个存放消息的List
        List<Message> messages = sqs.receiveMessage(receiveMessageRequest).getMessages();
        // 遍历List，打印消息内容
        StringBuilder s= new StringBuilder();
        for (Message message : messages) {
            System.out.println("收到：: " + message.getBody());
            // 删除已被接收的消息
           s.insert(0, "收到：" + message.getBody() + "\r\n");
            sqs.deleteMessage(queueUrl, message.getReceiptHandle());
        }
        return s.toString();
    }

    /**
     * 删除Queue
     */
    static void deleteQueue(String queueUrl) {
        sqs.deleteQueue(queueUrl);
    }
}