import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.SubscribeResult;

public class testSns {
    public static void main(String[] args) {
       //CreateTopicResult topic = sns.createTopic("test-topic");
       //SubscribeResult subscribe = sns.subscribe(topic.getTopicArn(), "email", "likanglin@cug.edu.cn");
        String token="2336412f37fb687f5d51e6e241dbca52e6afbedd08b18ecb6940cdc51299a2e5668bd67e48121497844c34218015b93c785efb592a440b1a8574d0146bd816848efb2e33b5cea8f40220f8bb6bc659289df2b622a8a15d87e356a99695bca5089ab785aea4b04f3e00abcf25010cb85a";
        sns.confirmSubscription("arn:aws:sns:us-east-1:433577412068:test-topic",token);
        sns.publish("arn:aws:sns:us-east-1:433577412068:test-topic", "Hi man", "Hi girl");
        sns.unsubscribe("arn:aws:sns:us-east-1:433577412068:test-topic:e158ae07-a68e-4f6f-bb60-b11d5b13a46e");
        sns.deleteTopic("arn:aws:sns:us-east-1:433577412068:test-topic");
    }
}
