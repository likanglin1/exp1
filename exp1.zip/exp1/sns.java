import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.*;

public class sns {
    private static AmazonSNS sns;
    static{
        sns= AmazonSNSClientBuilder.standard().withRegion(Regions.US_EAST_1).build();

    }
    private sns(){}
    //topic-arn 的值为复制的主题 ARN，
    //endpoint 的值替换为要订阅到主题的电子邮件地址
    //创建可以发布通知的topic
    public static CreateTopicResult createTopic(String name) {
        return sns.createTopic(name);
    }
//删除topic
    public static DeleteTopicResult deleteTopic(String topicArn) {
        return sns.deleteTopic(topicArn);
    }
//向端点发送确认信息，准备订阅端点
    public static SubscribeResult subscribe(String topicArn, String protocol, String endpoint) {
        return sns.subscribe(topicArn, protocol, endpoint);
    }

//删除订阅
    public static UnsubscribeResult unsubscribe(String subscriptionArn) {
        return sns.unsubscribe(subscriptionArn);
    }
//验证令牌，验证端点所有者接收消息的意图
    public static ConfirmSubscriptionResult confirmSubscription(String topicArn, String token) {
        return sns.confirmSubscription(topicArn, token);
    }
//发布订阅
    public static PublishResult publish(String topicArn, String message, String subject) {
        return sns.publish(topicArn, message, subject);
    }
}

